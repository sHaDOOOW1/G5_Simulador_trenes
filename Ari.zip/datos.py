#################################################################
#				¡¡¡¡CAMBIAR ESTO POR LA LISTA REAL!!!!			#
#################################################################
estaciones = ["Estacion Central", "Rancagua", "Talca", "Chillan"]
rutas = list(range(6))
trenes = []